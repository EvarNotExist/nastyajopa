import './App.css';
const apiKey = 'f2c3d63b2c94908a16f22ae599b709aa';

function App() {

  const Weather = () => {

    var city = document.getElementById('inp').value;

    var url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${apiKey}&lang=ru`;
    fetch(url)
      .then(response => {
        return response.json();
      })
      .then(data => {
        if (data.cod === '404') {
          console.log(data);
          document.getElementById("answerCity").innerHTML = "Такого города нет";
        } else {
          var iconCode = data.weather[0].icon;
          console.log(data);
          var urlIcon = `https://openweathermap.org/img/wn/${iconCode}@4x.png`;
          document.getElementById("answerCity").innerHTML = data.name;
          document.getElementById("answer").innerHTML = Math.round(data.main.temp)+" °C";
          document.getElementById("answerIcon").src = urlIcon;
          document.getElementById("answerIconDesc").innerHTML = data.weather[0].description;
        }
      })
  }

  return (
    <div className="App">
      <input className='inpCity' id="inp" type="text" name="name" defaultValue={''}/>
      <input className='inpBtn' onClick={Weather} type="button" name="name" value={'Узнать погоду'}/>
      <div className='temp'>
        <div id="answerCity">Введите город</div>
        <div id="answer"></div>
      </div>
      <div>
        <img id="answerIcon" src="" alt=""></img>
        <div id="answerIconDesc"></div>
      </div>
    </div>
  );
}

export default App;
